import os
import zipfile
import smtplib
from flask import Flask, render_template, request
from email.message import EmailMessage
from utils import create_mashup

app = Flask(__name__)


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        singer = request.form["singer"]
        num_videos = int(request.form["num_videos"])
        duration = int(request.form["duration"])
        email = request.form["email"]

        output_mp3 = "mashup.mp3"
        zip_name = "mashup.zip"

        create_mashup(singer, num_videos, duration, output_mp3)

        with zipfile.ZipFile(zip_name, "w") as z:
            z.write(output_mp3)

        send_email(email, zip_name)

        return "Mashup sent to your email!"

    return render_template("index.html")


def send_email(receiver, file_path):
    sender = "tkaur1_be23@thapar.edu"
    password = "ypzapbftfismzskf"

    msg = EmailMessage()
    msg["Subject"] = "Your Mashup File"
    msg["From"] = sender
    msg["To"] = receiver
    msg.set_content("Your mashup is attached.")

    with open(file_path, "rb") as f:
        msg.add_attachment(f.read(), maintype="application",
                           subtype="zip", filename=file_path)

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
        smtp.login(sender, password)
        smtp.send_message(msg)


if __name__ == "__main__":
    app.run(debug=True)
