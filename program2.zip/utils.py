import os
from yt_dlp import YoutubeDL
from pydub import AudioSegment


def create_mashup(singer, num_videos, duration, output_file):
    os.makedirs("downloads", exist_ok=True)

    query = f"ytsearch{num_videos}:{singer} songs"

    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": "downloads/%(id)s.%(ext)s",
        "quiet": True
    }

    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([query])

    clips = []

    for file in os.listdir("downloads"):
        path = os.path.join("downloads", file)
        audio = AudioSegment.from_file(path)
        clips.append(audio[: duration * 1000])

    final_audio = sum(clips)
    final_audio.export(output_file, format="mp3")
